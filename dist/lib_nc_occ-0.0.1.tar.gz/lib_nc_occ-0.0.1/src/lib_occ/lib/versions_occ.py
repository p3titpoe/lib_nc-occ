from lib_occ.creation import occ_command_lib as cmdlib
from lib_occ.logic import NCOcc
from dataclasses import dataclass

@dataclass(init=False)
class NcOccVersions(NCOcc):
    def __init__(self,libs:dict = cmdlib.versions):
        if libs is None:
            libs = {}
        super().__init__(libs)
        
    def cleanup(self):
        " Delete versions"
        cmd = self._lib['cleanup']['command']
        return self._process([cmd])
                    
    def expire(self):
        "Expires the users file versions"
        cmd = self._lib['expire']['command']
        return self._process([cmd])
                    
