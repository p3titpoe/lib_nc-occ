#!/usr/bin/python
#from lib import nc_occ as occ
#from .lib import nc_occ as occ
from lib_occ.nc_occ import Files
from pprint import pp
from lib_occ.logic import root,base
print(base)


tt = Files()
tt.section_func_list
tt.object.section_func_list

